<?php 

    // Start Page
    $site_title = 'BACS 350 - Demo Server';
    $page_title = 'Includes Design Pattern';
    include "header.php"; 


    // Your PHP content goes here
    require 'content.html';


    // End Page
    include "footer.php"; 
?>
