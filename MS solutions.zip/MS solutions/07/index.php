<?php

    // Start the page
    $page_title = 'BACS 350 - Project #7 - List Records';
    require_once '../../header.php';


    // Display subscriber records
    require 'select.php';


    // End the page
    require_once '../../footer.php';

?>
