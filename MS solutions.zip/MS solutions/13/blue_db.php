<?php
    
    // Bluehost Database settings

    $host = 'localhost';
    $port = '3306';
    $dbname = 'uncobacs_books';
    $username = 'uncobacs_350';
    $password = 'BACS_350';
    $db_connect = "mysql:host=$host:$port;dbname=$dbname";
    
?>